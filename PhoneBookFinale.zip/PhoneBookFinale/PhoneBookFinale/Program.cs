﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PhoneBookFinale.View;

namespace PhoneBookFinale
{
    class Program
    {
        static void Main(string[] args)
        {
            LoginView login = new LoginView();
            login.Show();
        }
    }
}
