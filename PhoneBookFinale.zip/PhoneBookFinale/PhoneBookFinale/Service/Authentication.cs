﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PhoneBookFinale.Entity;
using PhoneBookFinale.Repository;

namespace PhoneBookFinale.Service
{
    class Authentication
    {
        public static User LoggedUser { get; set; }
        public static Contact LoggedContact { get; set; }

        public static void Authenticator(string username , string password)
        {
            UserRepository userRepo = new UserRepository();
            User user = new User();

            user = userRepo.checkByUsernameAndPassword(username, password);

            if (user != null)
            {
                LoggedUser = user;
            }
        }
    }
}
