﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhoneBookFinale.Tools
{
    class Enumerations
    {
        public enum AdminOptions
        {
            AddUser = 1,
            RemoveUser = 2,
            DisplayUsers = 3,
            EditUser = 4,
            GoToUserView = 5,
            Exit = 6
        }
        public enum PhoneOptions
        {
            AddContact = 1,
            RemoveContact = 2,
            EditContact = 3,
            ViewAllContacts = 4,
            BackToUserView = 5,
            GoToContact
        }
        public enum UserOptins
        {
            AddPhone = 1,
            RemovePhone = 2,
            EditPhone = 3,
            ViewMyPhones = 4,
            GoToAPhone = 5,
            Exit = 6
        }
    }
}
