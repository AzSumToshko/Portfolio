﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhoneBookFinale.View
{
    internal class AdminOptionView
    {
        public void show()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("What do you want to do ?");
                Console.WriteLine("Go to [U]sers");
                Console.WriteLine("Go to [C]ontacts");
                Console.WriteLine("E[x]it");
                Console.Write("insert answer : ");
                switch (Console.ReadLine().ToLower())
                {
                    case "u":
                        AdminView admin = new AdminView();
                        admin.show();
                        break;

                    case "c":
                        ContactView phone = new ContactView();
                        phone.show();
                        break;
                    case "x":
                        return;

                    default:
                        break;
                }
            }
        }
    }
}
