﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PhoneBookFinale.Tools;
using PhoneBookFinale.Service;
using PhoneBookFinale.Repository;
using PhoneBookFinale.Entity;

namespace PhoneBookFinale.View
{
    class ContactView
    {
        public void show()
        {
            while (true)
            {
                Enumerations.PhoneOptions option = RenderMenu();

                switch (option)
                {
                    case Enumerations.PhoneOptions.AddContact:
                        Add();
                        break;
                    case Enumerations.PhoneOptions.RemoveContact:
                        Delete();
                        break;
                    case Enumerations.PhoneOptions.EditContact:
                        Edit();
                        break;
                    case Enumerations.PhoneOptions.ViewAllContacts:
                        DisplayAll();
                        break;
                    case Enumerations.PhoneOptions.GoToContact:
                        Go();
                        break;
                    case Enumerations.PhoneOptions.BackToUserView:
                        return;
                    default:
                        Console.WriteLine("Error.");
                        break;
                }
            }
        }

        public Enumerations.PhoneOptions RenderMenu()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("User Info");
                Console.WriteLine("ID : " + Authentication.LoggedUser.ID);
                Console.WriteLine("Username : " + Authentication.LoggedUser.username);
                Console.WriteLine("=========================");
                Console.WriteLine("Options");
                Console.WriteLine("[A]dd contact");
                Console.WriteLine("[R]emove contact");
                Console.WriteLine("[E]dit contact");
                Console.WriteLine("[V]iew all contacts");
                Console.WriteLine("[G]o to contact");
                Console.WriteLine("E[x]it");
                string answer = Console.ReadLine();

                switch (answer.ToUpper())
                {
                    case "A":
                        return Enumerations.PhoneOptions.AddContact;
                    case "R": 
                        return Enumerations.PhoneOptions.RemoveContact;
                    case "E": 
                        return Enumerations.PhoneOptions.EditContact;
                    case "V": 
                        return Enumerations.PhoneOptions.ViewAllContacts;
                    case "G":
                        return Enumerations.PhoneOptions.GoToContact;
                    case "X": 
                        return Enumerations.PhoneOptions.BackToUserView;
                    default:
                        Console.WriteLine("Invalid input.");
                        break;
                }
            } 
        }
        public void Go()
        {
            ContactRepository contactRepository = new ContactRepository();
            Console.Clear();
            Console.Write("ID of contact : ");
            int id = int.Parse(Console.ReadLine());
            contactRepository.GoToContact(id);
            if (Authentication.LoggedContact != null)
            {
                PhoneView phone = new PhoneView();
                phone.show();
            }
        }
        public void Add()
        {
            Console.Clear();
            ContactRepository repo = new ContactRepository();

            Console.WriteLine("Insert Contact name : ");
            string name = Console.ReadLine();


            repo.AddContact(name);
        }
        public void Delete()
        {
            Console.Clear();
            ContactRepository repo = new ContactRepository();

            Console.WriteLine("Insert id : ");
            int id = int.Parse(Console.ReadLine());

            if (repo.IsExisting(id))
            {
                repo.DeleteContact(id);
            }
            else
            {
                Console.WriteLine("Contact not found.");
                Console.ReadKey();
            }
        }
        public void Edit()
        {
            Console.Clear();
            ContactRepository repo = new ContactRepository();

            Console.WriteLine("insert id : ");
            int id = int.Parse(Console.ReadLine());

            if (repo.IsExisting(id))
            {
                Console.WriteLine("Insert new name : ");
                string name = Console.ReadLine();


                repo.EditContact(id, name);
            }
            else
            {
                Console.WriteLine("Contact not found.");
                Console.ReadKey();
            }
        }
        public void DisplayAll()
        {
            Console.Clear();
            ContactRepository repo = new ContactRepository();
            List<Contact> list = repo.GetAllContacts();

            foreach (var item in list)
            {
                Console.WriteLine("Contact ID : " + item.ID);
                Console.WriteLine("Contact parent ID : " + item.parentID);
                Console.WriteLine("Contact name : " + item.contactName);
                Console.WriteLine();
            }
            Console.ReadKey();
        }
    }
}
