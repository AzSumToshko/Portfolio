﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PhoneBookFinale.Tools;
using PhoneBookFinale.Service;
using PhoneBookFinale.Repository;
using PhoneBookFinale.Entity;
using PhoneBookFinale.DataBaseAccess;

namespace PhoneBookFinale.View
{
    class UserView
    {
        public void show()
        {
            while (true)
            {
                try
                {
                    Enumerations.UserOptins options = RenderMenu();

                    switch (options)
                    {
                        case Enumerations.UserOptins.AddPhone:
                            Add();
                            break;
                        case Enumerations.UserOptins.RemovePhone:
                            Delete();
                            break;
                        case Enumerations.UserOptins.EditPhone:
                            Edit();
                            break;
                        case Enumerations.UserOptins.ViewMyPhones:
                            DisplayAll();
                            break;
                        case Enumerations.UserOptins.GoToAPhone:
                            GoToPhone();
                            break;
                        case Enumerations.UserOptins.Exit:
                            return;
                        default:
                            Console.WriteLine("Error.");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }

        public Enumerations.UserOptins RenderMenu()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("Info");
                Console.WriteLine("ID : " + Authentication.LoggedUser.ID);
                Console.WriteLine("Username : " + Authentication.LoggedUser.username);
                Console.WriteLine("Password : " + Authentication.LoggedUser.password);
                Console.WriteLine("First Name : " + Authentication.LoggedUser.firstName);
                Console.WriteLine("Last Name : " + Authentication.LoggedUser.lastName);
                Console.WriteLine("Admin state: " + Authentication.LoggedUser.isAdmin);
                Console.WriteLine("=========================");
                Console.WriteLine("Options");
                Console.WriteLine("[A]dd Phone");
                Console.WriteLine("[D]elete Phone");
                Console.WriteLine("[E]dit Phone");
                Console.WriteLine("[G]et my phones");
                Console.WriteLine("G[o] to a Phone");
                Console.WriteLine("E[x]it");
                string answer = Console.ReadLine();

                switch (answer.ToUpper())
                {
                    case "A":
                        return Enumerations.UserOptins.AddPhone;
                    case "D":
                        return Enumerations.UserOptins.RemovePhone;
                    case "E":
                        return Enumerations.UserOptins.EditPhone;
                    case "G":
                        return Enumerations.UserOptins.ViewMyPhones;
                    case "O":
                        return Enumerations.UserOptins.GoToAPhone;
                    case "X":
                        return Enumerations.UserOptins.Exit;
                    default:
                        Console.WriteLine("Invalid input .");break;
                }
            }
        }

        public void Add()
        {
            Console.Clear();
            PhoneRepository repo = new PhoneRepository();

            Console.WriteLine("Insert phone number : ");
            string number = Console.ReadLine();

            repo.AddPhone(number);
        }
        public void Delete()
        {
            Console.Clear();
            PhoneRepository repo = new PhoneRepository();

            Console.WriteLine("insert phone id : ");
            int id = int.Parse(Console.ReadLine());

            if (repo.isExisting(id))
            {
                    repo.DeletePhone(id);
            }
            else
            {
                Console.WriteLine("Phone not found.");
                Console.ReadKey();
            }
        }
        public void Edit()
        {
            Console.Clear();
            PhoneRepository repo = new PhoneRepository();

            Console.WriteLine("insert phone id : ");
            int id = int.Parse(Console.ReadLine());
            if (repo.isExisting(id))
            {
                Console.WriteLine("insert new number : ");
                string newNumber = Console.ReadLine();

                repo.EditPhone(id,newNumber);
            }
            else
            {
                Console.WriteLine("Phone not found . ");
                Console.ReadKey();
            }
        }
        public void DisplayAll()
        {
            Console.Clear();
            PhoneRepository repo = new PhoneRepository();
            List<Phone> list = repo.GetAllPhones();

            foreach (var item in list)
            {
                Console.WriteLine("Phone ID : " + item.ID);
                Console.WriteLine("Phone parent ID : " + item.parentID);
                Console.WriteLine("Phone number : " + item.phoneNumber);
                Console.WriteLine();
            }
            Console.ReadKey();
        }
        public void GoToPhone()
        {
            Console.Clear();
            PhoneView view = new PhoneView();
            view.show();
        }
    }
}
