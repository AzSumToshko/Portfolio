﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PhoneBookFinale.Tools;
using PhoneBookFinale.Service;
using PhoneBookFinale.Repository;
using PhoneBookFinale.Entity;

namespace PhoneBookFinale.View
{
    class AdminView
    {
        public void show()
        {
            while (true)
            {
                Enumerations.AdminOptions options = RenderMenu();
                try
                {
                    switch (options)
                    {
                        case Enumerations.AdminOptions.AddUser:
                            Add();
                            break;
                        case Enumerations.AdminOptions.RemoveUser:
                            Remove();
                            break;
                        case Enumerations.AdminOptions.DisplayUsers:
                            Display();
                            break;
                        case Enumerations.AdminOptions.EditUser:
                            Edit();
                            break;
                        case Enumerations.AdminOptions.GoToUserView:
                            ContactView view = new ContactView();
                            view.show();
                            break;
                        case Enumerations.AdminOptions.Exit:
                            return;
                        default:
                            Console.WriteLine("Invalid input");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }

        public Enumerations.AdminOptions RenderMenu()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("Info");
                Console.WriteLine("ID : "+ Authentication.LoggedUser.ID);
                Console.WriteLine("Username : " + Authentication.LoggedUser.username);
                Console.WriteLine("=========================");
                Console.WriteLine("Options");
                Console.WriteLine("[A]dd user");
                Console.WriteLine("[R]emove user");
                Console.WriteLine("[D]isplay users");
                Console.WriteLine("[E]dit user");
                Console.WriteLine("[G]o to contacts");
                Console.WriteLine("E[x]it");
                string answer = Console.ReadLine();

                switch (answer.ToUpper())
                {
                    case "A":
                        return Enumerations.AdminOptions.AddUser;
                    case "R":
                        return Enumerations.AdminOptions.RemoveUser;
                    case "D":
                        return Enumerations.AdminOptions.DisplayUsers;
                    case "E":
                        return Enumerations.AdminOptions.EditUser;
                    case "G":
                        return Enumerations.AdminOptions.GoToUserView;
                    case "X":
                        return Enumerations.AdminOptions.Exit;
                    default:
                        Console.WriteLine("invalid input !"); break;
                }
            }
        }

        public void Add()
        {
            Console.Clear();
            UserRepository repo = new UserRepository();

            Console.WriteLine("insert username : ");
            string username = Console.ReadLine();

            Console.WriteLine("insert password : ");
            string password = Console.ReadLine();

            Console.WriteLine("insert first name : ");
            string firstName = Console.ReadLine();

            Console.WriteLine("insert last name : ");
            string lastName = Console.ReadLine();

            Console.WriteLine("insert admin state (true/false) : ");
            bool isAdmin = bool.Parse(Console.ReadLine());

            repo.AddUser(username, password, firstName, lastName, isAdmin);
        }

        public void Remove()
        {
            Console.Clear();
            UserRepository repo = new UserRepository();

            Console.WriteLine("insert user id : ");
            int id = int.Parse(Console.ReadLine());

            repo.Deleteuser(id);
        }

        public void Display()
        {
            Console.Clear();
            UserRepository repo = new UserRepository();
            List<User> list = repo.GetUsersList();

            foreach (var item in list)
            {
                Console.WriteLine("ID : " + item.ID);
                Console.WriteLine("Username : " + item.username);
                Console.WriteLine("Password : " + item.password);
                Console.WriteLine("First name : " + item.firstName);
                Console.WriteLine("Last name : " + item.lastName);
                Console.WriteLine("Admin : " + item.isAdmin);
                Console.WriteLine();
            }
            Console.ReadKey();
        }

        public void Edit()
        {
            UserRepository repo = new UserRepository();
            Console.Clear();
            Console.WriteLine("ID of user : ");
            int id = int.Parse(Console.ReadLine());

            if (repo.isExisting(id))
            {
                Console.WriteLine("Username : ");
                string username = Console.ReadLine();

                Console.WriteLine("Password : ");
                string password = Console.ReadLine();

                Console.WriteLine("First name : ");
                string first = Console.ReadLine();

                Console.WriteLine("Last name : ");
                string last = Console.ReadLine();

                Console.WriteLine("Admin state (true/false) : ");
                bool isAdmin = bool.Parse(Console.ReadLine());

                repo.EditUser(id, username, password, first, last, isAdmin);
            }
            else
            {
                Console.WriteLine("The database does not have a user with that id .");
                Console.ReadKey();
            }
        }
    }
}
