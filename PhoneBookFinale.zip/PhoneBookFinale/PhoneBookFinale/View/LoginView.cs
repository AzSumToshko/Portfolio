﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PhoneBookFinale.Service;
using PhoneBookFinale.Repository;

namespace PhoneBookFinale.View
{
    class LoginView
    {
        public void Show()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("Login or Create user (loggin/create) : ");
                string answer = Console.ReadLine();

                switch (answer.ToLower())
                {
                    case "loggin":
                        Console.Clear();
                        Console.WriteLine("Login");
                        Console.WriteLine("Username : ");
                        string username = Console.ReadLine();

                        Console.WriteLine("Password : ");
                        string password = Console.ReadLine();

                        Authentication.Authenticator(username, password);

                        if (Authentication.LoggedUser != null)
                        {
                            Console.Clear();
                            Console.WriteLine("Hello " + Authentication.LoggedUser.username);
                            Console.ReadKey();
                            if (Authentication.LoggedUser.isAdmin)
                            {
                                AdminOptionView admin = new AdminOptionView();
                                admin.show();
                                return;
                            }
                            else
                            {
                                ContactView View = new ContactView();
                                View.show();
                                return;
                            }
                        }
                        break;
                    case "create":
                        Console.Clear();
                        UserRepository repo = new UserRepository();

                        Console.WriteLine("Insert username : ");
                        string createUsername = Console.ReadLine();

                        Console.WriteLine("Insert password");
                        string createPassword = Console.ReadLine();

                        Console.WriteLine("Insert first name : ");
                        string first = Console.ReadLine();

                        Console.WriteLine("Insert last name : ");
                        string last = Console.ReadLine();

                        try
                        {
                                Console.WriteLine("Is admin (true/false) : ");
                                bool isAdmin = bool.Parse(Console.ReadLine());

                            repo.AddUser(createUsername, createPassword, first, last, isAdmin);

                            Authentication.Authenticator(createUsername, createPassword);

                            if (Authentication.LoggedUser != null)
                            {
                                Console.Clear();
                                Console.WriteLine("Hello " + Authentication.LoggedUser.username);
                                Console.ReadKey();
                                if (Authentication.LoggedUser.isAdmin)
                                {
                                    AdminOptionView admin = new AdminOptionView();
                                    admin.show();
                                    return;
                                }
                                else
                                {
                                    ContactView View = new ContactView();
                                    View.show();
                                    return;
                                }
                            }
                        }
                        catch (Exception)
                        {
                            Console.WriteLine("invalid input.");
                        }
                        break;
                    default:
                        Console.WriteLine("Invalid input.");
                        break;
                }
                
            }
        }
    }
}
