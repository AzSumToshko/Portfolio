﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PhoneBookFinale.DataBaseAccess;
using PhoneBookFinale.Entity;
using PhoneBookFinale.Service;

namespace PhoneBookFinale.Repository
{
    class PhoneRepository
    {
        public bool isExisting(int id)
        {
            Context context = new Context();

            foreach (var item in context.Phones)
            {
                if (item.ID == id)
                {
                    return true;
                }
            }
            return false;
        }
        public void AddPhone(string phoneNumber)
        {
            Context context = new Context();
            Phone phone = new Phone();
            phone.parentID = Authentication.LoggedContact.ID;
            phone.phoneNumber = phoneNumber;

            context.Phones.Add(phone);
            context.SaveChanges();
        }
        public void DeletePhone(int id)
        {
            Context context = new Context();
            foreach (var item in context.Phones)
            {
                if (id == item.ID)
                {
                    context.Phones.Remove(item);
                }
            }
            context.SaveChanges();
        }
        public void DeleteByParent(int parent)
        {
            Context ctx = new Context();
            foreach(var item in ctx.Phones)
            {
                if (item.parentID==parent)
                {
                    ctx.Phones.Remove(item);
                }
            }
            ctx.SaveChanges();
        }
        public void EditPhone(int id ,string editNumber)
        {
            Context context = new Context();
            Phone item = context.Phones.Find(id);

            item.phoneNumber = editNumber;

            context.Entry(item).State = EntityState.Modified;
            context.SaveChanges();
        }
        public List<Phone> GetAllPhones()
        {
            Context context = new Context();
            List<Phone> list = new List<Phone>();
            foreach (var item in context.Phones)
            {
                if (item.parentID == Authentication.LoggedContact.ID)
                {
                        list.Add(item);
                }
            }
            return list;
        }
    }
}
