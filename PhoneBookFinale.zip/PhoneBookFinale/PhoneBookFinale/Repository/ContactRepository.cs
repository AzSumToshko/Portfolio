﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PhoneBookFinale.DataBaseAccess;
using PhoneBookFinale.Entity;
using PhoneBookFinale.Service;

namespace PhoneBookFinale.Repository
{
    class ContactRepository
    {
        public bool IsExisting(int id)
        {
            Context context = new Context();

            foreach (var item in context.Contacts)
            {
                if (item.ID == id)
                {
                    return true;
                }
            }
            return false;
        }
        public void GoToContact(int id)
        {
            Context context = new Context();
            foreach(var item in context.Contacts)
            {
                if (item.ID == id)
                {
                    Authentication.LoggedContact = item;
                }
            }
        }
        public void AddContact(string name)
        {
            Context context = new Context();
            Contact contact = new Contact();

            contact.parentID = Authentication.LoggedUser.ID;
            contact.contactName = name;

            context.Contacts.Add(contact);
            context.SaveChanges();
        }
        public void DeleteContact(int id)
        {
            Context context = new Context();
            foreach (var item in context.Phones)
            {
                if (item.parentID == id)
                {
                    context.Phones.Remove(item);
                }
            }
            foreach (var item in context.Contacts)
            {
                if (item.ID == id)
                {
                    context.Contacts.Remove(item);
                }
            }
            context.SaveChanges();
        }
        public void DeleteByParent(int parent)
        {
            Context context= new Context();
            PhoneRepository phoneRepository = new PhoneRepository();
            foreach (var item in context.Contacts)
            {
                if (parent == item.parentID)
                {
                    phoneRepository.DeleteByParent(item.ID);
                    context.Contacts.Remove(item);
                }
            }
            context.SaveChanges();
        }
        public void EditContact(int id , string name)
        {
            Context context = new Context();
            Contact contact = context.Contacts.Find(id);

            contact.contactName = name;

            context.Entry(contact).State = EntityState.Modified;
            context.SaveChanges();
        }
        public List<Contact> GetAllContacts()
        {
            Context context = new Context();
            List<Contact> list = new List<Contact>();

            foreach (var item in context.Contacts)
            {
                if (item.parentID == Authentication.LoggedUser.ID)
                {
                    list.Add(item);
                }
            }
            return list;
        }
    }
}
