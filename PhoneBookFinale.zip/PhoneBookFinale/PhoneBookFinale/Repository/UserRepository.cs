﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PhoneBookFinale.DataBaseAccess;
using PhoneBookFinale.Entity;

namespace PhoneBookFinale.Repository
{
    class UserRepository
    {
        public User checkByUsernameAndPassword(string username,string password)
        {
            Context context = new Context();
            foreach (var item in context.Users)
            {
                if (item.username == username && item.password == password)
                {
                    return item;
                }
            }
            return null;
        }

        public bool isExisting(int id)
        {
            Context context = new Context();

            foreach (var item in context.Users)
            {
                if (item.ID == id)
                {
                    return true;
                }
            }
            return false;
        }
        public void AddUser(string username , string password , string first , string last , bool admin)
        {
            Context context = new Context();
            User user = new User();

            user.username = username;
            user.password = password;
            user.firstName = first;
            user.lastName = last;
            user.isAdmin = admin;

            context.Users.Add(user);
            context.SaveChanges();
        }
        public void Deleteuser(int id)
        {
            Context context = new Context();
            ContactRepository contactRepository = new ContactRepository();
            foreach(var item in context.Users)
            {
                if (item.ID == id)
                {
                    contactRepository.DeleteByParent(item.ID);
                    context.Users.Remove(item);
                }
            }
            context.SaveChanges();
        }
        public void EditUser(int id , string username,string password , string first,string last,bool isAdmin)
        {
            Context context = new Context();
            User item = context.Users.Find(id);

            item.username = username;
            item.password = password;
            item.firstName = first;
            item.lastName = last;
            item.isAdmin = isAdmin;

            context.Entry(item).State = EntityState.Modified;
            context.SaveChanges();
        }
        public List<User> GetUsersList()
        {
            Context context = new Context();
            List<User> list = new List<User>();

            foreach (var item in context.Users)
            {
                list.Add(item);
            }

            return list;
        }
    }
}
