﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using PhoneBookFinale.Entity;


namespace PhoneBookFinale.DataBaseAccess
{
    class Context : DbContext
    {
        public DbSet<User> Users { get; set; }
        public DbSet<Phone> Phones { get; set; }
        public DbSet<Contact> Contacts { get; set; }

        public Context() : base("Server = localhost\\sqlexpress; Database=PhoneRegister.dbo;Trusted_Connection=True;")
        {
            Users = this.Set<User>();
            Phones = this.Set<Phone>();
            Contacts = this.Set<Contact>();
        }
    }
}
