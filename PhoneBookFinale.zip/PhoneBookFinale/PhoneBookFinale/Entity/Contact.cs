﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace PhoneBookFinale.Entity
{
    [Table("ContactsTable")]
    class Contact
    {
        [Key]
        public int ID { get; set; }
        public int parentID { get; set; }
        public string contactName { get; set; }
    }
}
