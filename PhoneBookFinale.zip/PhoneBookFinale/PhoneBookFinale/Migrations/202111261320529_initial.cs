﻿namespace PhoneBookFinale.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class initial : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.ContactsTable",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        parentID = c.Int(nullable: false),
                        contactName = c.String(),
                    })
                .PrimaryKey(t => t.ID);
            
            CreateTable(
                "dbo.PhonesTable",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        parentID = c.Int(nullable: false),
                        phoneNumber = c.String(),
                    })
                .PrimaryKey(t => t.ID);
            
            CreateTable(
                "dbo.UsersTable",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        username = c.String(),
                        password = c.String(),
                        firstName = c.Int(nullable: false),
                        lastName = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.ID);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.UsersTable");
            DropTable("dbo.PhonesTable");
            DropTable("dbo.ContactsTable");
        }
    }
}
