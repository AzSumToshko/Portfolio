﻿namespace PhoneBookFinale.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class second : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.UsersTable", "firstName", c => c.String());
            AlterColumn("dbo.UsersTable", "lastName", c => c.String());
        }
        
        public override void Down()
        {
            AlterColumn("dbo.UsersTable", "lastName", c => c.Int(nullable: false));
            AlterColumn("dbo.UsersTable", "firstName", c => c.Int(nullable: false));
        }
    }
}
