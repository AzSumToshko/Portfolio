﻿namespace PhoneBookFinale.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class hopeLast : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.ContactsTable", "contcatNumber", c => c.String());
        }
        
        public override void Down()
        {
            DropColumn("dbo.ContactsTable", "contcatNumber");
        }
    }
}
