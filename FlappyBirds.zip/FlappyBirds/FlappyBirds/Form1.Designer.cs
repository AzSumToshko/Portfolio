﻿namespace FlappyBirds
{
    partial class GameScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GameScreen));
            this.GroundBox = new System.Windows.Forms.PictureBox();
            this.PipeUpBox = new System.Windows.Forms.PictureBox();
            this.PipeDownBox = new System.Windows.Forms.PictureBox();
            this.BirdBox = new System.Windows.Forms.PictureBox();
            this.GameTimer = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.GroundBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PipeUpBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PipeDownBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BirdBox)).BeginInit();
            this.SuspendLayout();
            // 
            // GroundBox
            // 
            this.GroundBox.Image = ((System.Drawing.Image)(resources.GetObject("GroundBox.Image")));
            this.GroundBox.Location = new System.Drawing.Point(-13, 605);
            this.GroundBox.Name = "GroundBox";
            this.GroundBox.Size = new System.Drawing.Size(1344, 147);
            this.GroundBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.GroundBox.TabIndex = 0;
            this.GroundBox.TabStop = false;
            // 
            // PipeUpBox
            // 
            this.PipeUpBox.Image = ((System.Drawing.Image)(resources.GetObject("PipeUpBox.Image")));
            this.PipeUpBox.Location = new System.Drawing.Point(861, 360);
            this.PipeUpBox.Name = "PipeUpBox";
            this.PipeUpBox.Size = new System.Drawing.Size(148, 245);
            this.PipeUpBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PipeUpBox.TabIndex = 2;
            this.PipeUpBox.TabStop = false;
            // 
            // PipeDownBox
            // 
            this.PipeDownBox.Image = ((System.Drawing.Image)(resources.GetObject("PipeDownBox.Image")));
            this.PipeDownBox.Location = new System.Drawing.Point(861, 0);
            this.PipeDownBox.Name = "PipeDownBox";
            this.PipeDownBox.Size = new System.Drawing.Size(148, 91);
            this.PipeDownBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PipeDownBox.TabIndex = 3;
            this.PipeDownBox.TabStop = false;
            // 
            // BirdBox
            // 
            this.BirdBox.Image = ((System.Drawing.Image)(resources.GetObject("BirdBox.Image")));
            this.BirdBox.Location = new System.Drawing.Point(71, 286);
            this.BirdBox.Name = "BirdBox";
            this.BirdBox.Size = new System.Drawing.Size(95, 67);
            this.BirdBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.BirdBox.TabIndex = 4;
            this.BirdBox.TabStop = false;
            // 
            // GameTimer
            // 
            this.GameTimer.Interval = 20;
            this.GameTimer.Tick += new System.EventHandler(this.TickEvent);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Wheat;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(12, 641);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(152, 39);
            this.label1.TabIndex = 5;
            this.label1.Text = "Score : 0";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // GameScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.ClientSize = new System.Drawing.Size(1264, 699);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BirdBox);
            this.Controls.Add(this.PipeDownBox);
            this.Controls.Add(this.PipeUpBox);
            this.Controls.Add(this.GroundBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "GameScreen";
            this.Text = "Flappy Birds";
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.KeyPressEvent);
            ((System.ComponentModel.ISupportInitialize)(this.GroundBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PipeUpBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PipeDownBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BirdBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox GroundBox;
        private System.Windows.Forms.PictureBox PipeUpBox;
        private System.Windows.Forms.PictureBox PipeDownBox;
        private System.Windows.Forms.PictureBox BirdBox;
        private System.Windows.Forms.Timer GameTimer;
        private System.Windows.Forms.Label label1;
    }
}

