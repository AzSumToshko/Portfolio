﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlappyBirds
{
    public partial class GameScreen : Form
    {
        public static bool isFinished;
        public static Random random;
        public static int counter;
        public static int GoUp;
        public static List<PictureBox> TopPipes;
        public static List<PictureBox> BottomPipes;
        public GameScreen()
        {
            InitializeComponent();
            isFinished = false;
            random = new Random();
            TopPipes = new List<PictureBox>();
            BottomPipes = new List<PictureBox>();
            TopPipes.Add(PipeDownBox);
            BottomPipes.Add(PipeUpBox);
            label1.Text = "Score : 0";
            counter = 0;
            GoUp = 0;
        }
        private void TickEvent(object sender, EventArgs e)
        {
            BirdBox.Location = new Point(BirdBox.Location.X, BirdBox.Location.Y+5); // svalq ptichkata nadolo

            foreach (PictureBox pipe in TopPipes)
            {
                pipe.Location = new Point(pipe.Location.X-5, pipe.Location.Y);
            }
            foreach (PictureBox pipe in BottomPipes)
            {
                pipe.Location = new Point(pipe.Location.X - 5, pipe.Location.Y);
            }

            MovingBird();

            if (BirdBox.Location.Y >= GroundBox.Location.Y-57) // ako pticata ugari zemqta 
            {
                GameTimer.Stop();
                isFinished = true;
            }

            if (BirdBox.Location.Y <= 0) // ako e na tavana da padne malko
            {
                BirdBox.Location = new Point(BirdBox.Location.X, 5);
            }


            checkIfUpperHits();
            checkIfDownHits();

            if (TopPipes.ElementAt(counter).Location.X <= 750)
            {
                GenerateNewPipes();
                counter++;
            }
            label1.Text = $"Score : {GetScore()}";
        }

        private int GetScore()
        {
            int counter = 0;
            foreach (var pipe in TopPipes)
            {
                if (pipe.Location.X < BirdBox.Location.X)
                {
                    counter++;
                }
            }
            return counter;
        }
        private void GenerateNewPipes()
        {
            PictureBox topPipe = new PictureBox();  
            PictureBox bottomPipe = new PictureBox();

            this.Controls.Add(topPipe);
            this.Controls.Add(bottomPipe);

            topPipe.Location = new Point(1250,0);
            topPipe.Width = 148;
            topPipe.Height = random.Next(0, 390);

            bottomPipe.Location = new Point(1250,topPipe.Height+220);
            bottomPipe.Width = 148;
            bottomPipe.Height = 605 - bottomPipe.Location.Y;

            topPipe.Image = Image.FromFile("pipedown.PNG");
            bottomPipe.Image = Image.FromFile("pipe.PNG");

            topPipe.SizeMode = PictureBoxSizeMode.StretchImage;
            bottomPipe.SizeMode = PictureBoxSizeMode.StretchImage;

            BottomPipes.Add(bottomPipe);
            TopPipes.Add(topPipe);
        }
        private void checkIfUpperHits()
        {
            foreach (var pipe in TopPipes)
            {
                if ((BirdBox.Location.Y >= pipe.Location.Y && BirdBox.Location.Y <= pipe.Location.Y + pipe.Size.Height) 
                    && (BirdBox.Location.X >= pipe.Location.X - BirdBox.Size.Width && BirdBox.Location.X <= pipe.Location.X + pipe.Size.Width))
                {
                    GameTimer.Stop();
                    isFinished = true;
                }
            }
        }
        private void checkIfDownHits()
        {
            foreach (var pipe in BottomPipes)
            {
                if ((BirdBox.Location.Y >= pipe.Location.Y - BirdBox.Size.Height)
               && (BirdBox.Location.X >= pipe.Location.X - BirdBox.Size.Width && BirdBox.Location.X <= pipe.Location.X + pipe.Size.Width))
                {
                    GameTimer.Stop();
                    isFinished=true;
                }
            }
        }
        private void KeyPressEvent(object sender, KeyPressEventArgs e)
        {
            if (isFinished)
            {
                Application.Restart();
                Environment.Exit(0);
            }
            if (!GameTimer.Enabled)
            {
                GameTimer.Start();
            }
            GoUp = 1;
        }
        private void MovingBird()
        {
            if (GoUp == 1)  //pticheto murda
            {
                for (int i = 0; i < 14; i++)
                {
                    BirdBox.Location = new Point(BirdBox.Location.X, BirdBox.Location.Y - 5);
                }
                GoUp = 0;
            }
        }
    }
}
