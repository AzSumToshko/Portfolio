﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BattleShips
{
    public partial class GameScreen : Form
    {
        public static Button[,] Buttons = new Button[10,10];

        public static int[,] PlayerOneGrid = new int[10, 10];
        public static int[,] PlayerTwoGrid = new int[10, 10];

        public static int playerOnePlacing = 0;
        public static int playerTwoPlacing = 0;

        public static int destroyedShipsOne = 0;
        public static int destroyedShipsTwo = 0;

        public static int playerTurn;
        public GameScreen()
        {
            InitializeComponent();
            GenerateButtons();
            AvailablePlaces();
            playerTurn = 1;
            UpdateBoardPLayerOne();
            TurnsLabel.Text = "PLAYER ONE : PLACING A SHIP";
        }
        private int CheckForWinner()
        {
            int p1Count = 0;
            int p2Count = 0;
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    if (PlayerOneGrid[i,j] == 1)
                    {
                        p1Count++;
                    }
                    if (PlayerTwoGrid[i,j] == 1)
                    {
                        p2Count++;
                    }
                }
            }
            if (p1Count > 0 && p2Count > 0)
            {
                return 0;
            }
            else if (p1Count == 0 && p2Count != 0)
            {
                return 2;
            }
            else if (p2Count == 0 && p1Count != 0)
            {
                return 1;
            }
            else
            {
                return 3;
            }
        }
        private void ClearButtonsInterface()
        {
            foreach (var item in Buttons)
            {
                item.BackColor = Color.DarkGoldenrod;
                item.Text = "";
            }
        }
        private void UpdateBoardPLayerOne()
        {
            ClearButtonsInterface();
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    if (PlayerOneGrid[i,j] == 0)
                    {
                        Buttons[i, j].Text = "";
                        Buttons[i, j].BackColor = Color.DarkGoldenrod;
                    }
                    else if (PlayerOneGrid[i, j] == 1 && playerTwoPlacing < 6)
                    {
                        Buttons[i, j].Text = "SHIP";
                        Buttons[i, j].BackColor = Color.Crimson;
                    }
                    else if (PlayerOneGrid[i, j] == 2)
                    {
                        Buttons[i, j].Text = "X";
                        Buttons[i, j].BackColor = Color.Cyan;
                    }
                }
            }
        }
        private void UpdateBoardPLayerTwo()
        {
            ClearButtonsInterface();
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    if (PlayerTwoGrid[i, j] == 0)
                    {
                        Buttons[i, j].Text = "";
                        Buttons[i, j].BackColor = Color.DarkGoldenrod;
                    }
                    else if (PlayerTwoGrid[i, j] == 1 && playerOnePlacing < 6)
                    {
                        Buttons[i, j].Text = "SHIP";
                        Buttons[i, j].BackColor = Color.Crimson;
                    }
                    else if (PlayerTwoGrid[i, j] == 2)
                    {
                        Buttons[i, j].Text = "X";
                        Buttons[i, j].BackColor = Color.Cyan;
                    }
                }
            }
        }
        private void AvailablePlaces()
        {
            if (playerTurn == 1)
            {
                
                for (int i = 0; i < 10; i++)
                {
                    for (int j = 0; j < 10; j++)
                    {
                        if (playerOnePlacing< 6)
                        {
                            if (PlayerTwoGrid[i, j] == 0)
                            {
                                Buttons[i, j].Enabled = true;
                            }
                            else
                            {
                                Buttons[i, j].Enabled = false;
                            }
                        }
                        else
                        {
                            if (PlayerOneGrid[i, j] == 2)
                            {
                                Buttons[i, j].Enabled = false;
                            }
                            else
                            {
                                Buttons[i, j].Enabled = true ;
                            }
                        }
                    }
                }
            }
            else if(playerTurn == 2)
            {
                for (int i = 0; i < 10; i++)
                {
                    for (int j = 0; j < 10; j++)
                    {
                        if (playerTwoPlacing < 6)
                        {
                            if (PlayerOneGrid[i, j] == 0)
                            {
                                Buttons[i, j].Enabled = true;
                            }
                            else
                            {
                                Buttons[i, j].Enabled = false;
                            }
                        }
                        else
                        {
                            if (PlayerTwoGrid[i, j] == 2)
                            {
                                Buttons[i, j].Enabled = false;
                            }
                            else
                            {
                                Buttons[i, j].Enabled = true;
                            }
                        }
                    }
                }
            }
        }
        private void DisableAllButtons()
        {
            foreach(var item in Buttons)
            {
                item.Enabled=false;
            }
        }
        private void GenerateButtons()
        {
            int x = 0;
            int y = 0;
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    Button newButton = new Button();
                    newButton.Click += HandleClickEvent;
                    this.Controls.Add(newButton);
                    panel1.Controls.Add(newButton);
                    newButton.Text = "";
                    newButton.Tag = $"{i}+{j}";
                    newButton.BackColor = Color.DarkGoldenrod;
                    newButton.Size = new Size(80,80);
                    newButton.Location = new Point(x,y);
                    Buttons[i,j] = newButton;

                    y += 80;
                }
                x += 80;
                y = 0;
            }
        }
        private void HandleClickEvent(object sender, EventArgs e)
        {
            Button clickedButton = (Button)sender;
            if (playerTurn == 1)
            {
                if (playerOnePlacing == 6) // tuka shte stava cqlata magiq sus strelqneto
                {
                    int[] indexes = clickedButton.Tag.ToString().Split('+').Select(n => int.Parse(n)).ToArray();
                    if (PlayerOneGrid[indexes[0], indexes[1]] == 1)
                    {
                        destroyedShipsOne++;
                    }
                    PlayerOneGrid[indexes[0], indexes[1]] = 2;
                    UpdateBoardPLayerTwo();
                    playerTurn = 2;
                    TurnsLabel.Text = $"PLAYER TWO : SHOOTING A SHOT . HE HAVE DESTROYED {destroyedShipsTwo} SHIPS.";
                }

                if (playerOnePlacing < 5) // postavqneto na korabi
                {
                    TurnsLabel.Text = "PLAYER ONE : PLACING A SHIP";
                    int[] indexes = clickedButton.Tag.ToString().Split('+').Select(n => int.Parse(n)).ToArray();
                    PlayerTwoGrid[indexes[0], indexes[1]] = 1;
                    playerOnePlacing++;
                    UpdateBoardPLayerTwo();
                }

                if (playerOnePlacing == 5) // zavurtane na poziciqta (tuka samo vednuj se vliza)
                {
                    playerOnePlacing++;
                    TurnsLabel.Text = "PLAYER TWO : PLACING A SHIP";
                    UpdateBoardPLayerOne();
                    playerTurn = 2;
                }

                
            }
            else if (playerTurn == 2)
            {
                if (playerTwoPlacing == 6) // tuka shte stava cqlata magiq sus strelqneto
                {
                    int[] indexes = clickedButton.Tag.ToString().Split('+').Select(n => int.Parse(n)).ToArray();
                    if (PlayerTwoGrid[indexes[0], indexes[1]] == 1)
                    {
                        destroyedShipsTwo++;
                    }
                    PlayerTwoGrid[indexes[0], indexes[1]] = 2;
                    UpdateBoardPLayerOne();
                    playerTurn = 1;
                    TurnsLabel.Text = $"PLAYER ONE : SHOOTING A SHOT . HE HAVE DESTROYED {destroyedShipsOne} SHIPS.";
                }
                if (playerTwoPlacing < 5)
                {
                    TurnsLabel.Text = "PLAYER TWO : PLACING A SHIP";
                    int[] indexes = clickedButton.Tag.ToString().Split('+').Select(n => int.Parse(n)).ToArray();
                    PlayerOneGrid[indexes[0], indexes[1]] = 1;
                    playerTwoPlacing++;
                    UpdateBoardPLayerOne();
                }
                if (playerTwoPlacing == 5)
                {
                    playerTwoPlacing++;
                    TurnsLabel.Text = $"PLAYER ONE : SHOOTING A SHOT . HE HAVE DESTROYED {destroyedShipsOne} SHIPS.";
                    UpdateBoardPLayerTwo();
                    playerTurn = 1;
                }
                
            }

            AvailablePlaces();

            if (CheckForWinner() == 2 && playerOnePlacing == 6 && playerTwoPlacing == 6)
            {
                TurnsLabel.Text = "PLAYER ONE WON THE GAME , BY DESTROING ALL ENEMY SHIPS !";
                UpdateBoardPLayerOne();
                DisableAllButtons();
                return;
            }
            if (CheckForWinner() == 1 && playerOnePlacing == 6 && playerTwoPlacing == 6)
            {
                TurnsLabel.Text = "PLAYER TWO WON THE GAME , BY DESTROING ALL ENEMY SHIPS !";
                UpdateBoardPLayerTwo();
                DisableAllButtons();
                return;
            }
        }
        private void GameScreen_Load(object sender, EventArgs e)
        {

        }
        private void NewGameButton_Click(object sender, EventArgs e)
        {
            playerOnePlacing = 0;
            playerTwoPlacing = 0;
            playerTurn = 1;
            ResetBoardsAndButtons();
            UpdateBoardPLayerOne();
            TurnsLabel.Text = "PLAYER ONE : PLACING A SHIP";
        }
        private void ResetBoardsAndButtons()
        {
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    PlayerOneGrid[i, j] = 0;
                    PlayerTwoGrid[i, j] = 0;

                    Buttons[i, j].Text = "";
                    Buttons[i, j].Enabled = true;
                    Buttons[i, j].BackColor = Color.DarkGoldenrod;
                }
            }
        }
    }
}
